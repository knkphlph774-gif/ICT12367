document.addEventListener('DOMContentLoaded', () => {
    const feedbackText = document.getElementById('feedbackText');
    const charCountDisplay = document.getElementById('charCount');
    const maxLengthDisplay = document.getElementById('maxLength');
    const charCounterWrapper = document.getElementById('charCounterWrapper');
    const charCountMessage = document.getElementById('charCountMessage');
    const progressBar = document.getElementById('charProgressBar');
    
   
    const MAX_LENGTH = 200;
    
   
    feedbackText.setAttribute('maxlength', MAX_LENGTH);
    maxLengthDisplay.textContent = MAX_LENGTH;
    
  
    const updateCharCount = () => {
        const currentLength = feedbackText.value.length;
        charCountDisplay.textContent = currentLength;
        
        const percentage = (currentLength / MAX_LENGTH) * 100;
        progressBar.style.width = `${percentage}%`;
        
       
        if (currentLength === 0) {
            charCounterWrapper.className = 'char-counter';
            charCountMessage.textContent = 'กรุณาพิมพ์ข้อความ...';
            progressBar.style.backgroundColor = 'var(--success-color)';
        } else if (currentLength < MAX_LENGTH * 0.7) {
            charCounterWrapper.className = 'char-counter';
            charCountMessage.textContent = 'กำลังพิมพ์...';
            progressBar.style.backgroundColor = 'var(--success-color)';
        } else if (currentLength < MAX_LENGTH * 0.9) {
            charCounterWrapper.className = 'char-counter warning';
            charCountMessage.textContent = 'ใกล้ถึงขีดจำกัดแล้ว';
            progressBar.style.backgroundColor = 'var(--warning-color)';
        } else {
            charCounterWrapper.className = 'char-counter danger';
            if (currentLength === MAX_LENGTH) {
                charCountMessage.textContent = 'ถึงขีดจำกัดตัวอักษรแล้ว!';
            } else {
                charCountMessage.textContent = 'ใกล้เต็มแล้ว!';
            }
            progressBar.style.backgroundColor = 'var(--error-color)';
        }
    };
    
    
    feedbackText.addEventListener('input', updateCharCount);
    
  
    feedbackText.addEventListener('paste', (e) => {
        const pasteData = (e.clipboardData || window.clipboardData).getData('text');
        if (feedbackText.value.length + pasteData.length > MAX_LENGTH) {
         
            charCounterWrapper.classList.remove('danger');
            void charCounterWrapper.offsetWidth; 
            charCounterWrapper.classList.add('danger');
        }
    });

   
    const form = document.getElementById('feedbackForm');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const btn = document.getElementById('submitBtn');
        const originalText = btn.innerHTML;
        
        btn.innerHTML = `
            <svg class="animate-spin h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" style="width:24px;height:24px;animation: spin 1s linear infinite;">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            กำลังส่งข้อมูล...
        `;
        
        
        setTimeout(() => {
            btn.innerHTML = 'ส่งข้อมูลสำเร็จ! 🎉';
            btn.style.backgroundColor = 'var(--success-color)';
            
            setTimeout(() => {
                form.reset();
                updateCharCount();
                btn.innerHTML = originalText;
                btn.style.backgroundColor = '';
            }, 3000);
        }, 1500);
    });
});


const style = document.createElement('style');
style.textContent = `
    @keyframes spin { 
        100% { transform: rotate(360deg); } 
    }
    .opacity-25 { opacity: 0.25; }
    .opacity-75 { opacity: 0.75; }
`;
document.head.appendChild(style);
