age =21
print("อายุของฉันคือ", age)

# ชิดซ้ายสุดแบบนี้
name = "กนกพล ภูมิชิน"
age = 21
print(f"สวัสดีฉันชื่อ{name}, ฉันอายุ{age}ปี")

print("Python", "Java", "C++", sep=" | ")
