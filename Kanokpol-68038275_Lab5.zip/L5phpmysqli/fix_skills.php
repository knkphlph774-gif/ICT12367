<?php
require('dbconnect.php');

echo "<h2>กำลังตรวจสอบและแก้ไขฐานข้อมูล...</h2>";
$check = mysqli_query($connect, "SHOW COLUMNS FROM employees LIKE 'Skills'");
if(mysqli_num_rows($check) > 0) {
    echo "พบคอลัมน์ 'Skills' (ตัวใหญ่) ... กำลังเปลี่ยนเป็น 'skills' (ตัวเล็ก)<br>";
    $sql = "ALTER TABLE employees CHANGE Skills skills VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL";
    if(mysqli_query($connect, $sql)){
        echo "✅ แก้ไขชื่อคอลัมน์สำเร็จ!<br>";
    } else {
        echo "❌ แก้ไขล้มเหลว: " . mysqli_error($connect) . "<br>";
    }
} else {
    $check_small = mysqli_query($connect, "SHOW COLUMNS FROM employees LIKE 'skills'");
    if(mysqli_num_rows($check_small) > 0) {
        echo "✅ พบคอลัมน์ 'skills' (ตัวเล็ก) ถูกต้องแล้ว พร้อมใช้งาน<br>";
    } else {
        echo "⚠️ ไม่พบคอลัมน์ 'skills' หรือ 'Skills' เลย!<br>";
        echo "รายชื่อคอลัมน์ที่มีปัจจุบัน: ";
        $all = mysqli_query($connect, "SHOW COLUMNS FROM employees");
        while($row = mysqli_fetch_assoc($all)) {
            echo "[" . $row['Field'] . "] ";
        }
        echo "<br>";
    }
}

echo "<br><hr><a href='L5index.php'>กลับไปหน้าแสดงผล</a>";
?>
