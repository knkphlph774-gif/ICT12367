<?php
$connect = mysqli_connect("127.0.0.1", "root", ""); 

if(!$connect){
    die("Connection failed: " . mysqli_connect_error());
}

$sql_db = "CREATE DATABASE IF NOT EXISTS mydatab DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci";
if(mysqli_query($connect, $sql_db)){

    mysqli_select_db($connect, "mydatab");
    
    $sql_table = "CREATE TABLE IF NOT EXISTS employees (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        fname VARCHAR(100) NOT NULL,
        lname VARCHAR(100) NOT NULL
    )";
    mysqli_query($connect, $sql_table);
}

if($connect){
}
?>
