<?php
// Redirect to the employee form page as the default landing page
header("Location: L5insertForm.php");
exit();
?>
