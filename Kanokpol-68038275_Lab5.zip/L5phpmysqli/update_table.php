<?php
require('dbconnect.php');

$check_gender = mysqli_query($connect, "SHOW COLUMNS FROM employees LIKE 'gender'");
if (mysqli_num_rows($check_gender) == 0) {
    $sql_gender = "ALTER TABLE employees ADD gender VARCHAR(20) NOT NULL AFTER lname";
    if (mysqli_query($connect, $sql_gender)) {
        echo "เพิ่มคอลัมน์ gender สำเร็จ<br>";
    } else {
        echo "เพิ่มคอลัมน์ gender ผิดพลาด: " . mysqli_error($connect) . "<br>";
    }
} else {
    echo "มีคอลัมน์ gender อยู่แล้ว<br>";
}

$check_skills = mysqli_query($connect, "SHOW COLUMNS FROM employees LIKE 'skills'");
if (mysqli_num_rows($check_skills) == 0) {
    $sql_skills = "ALTER TABLE employees ADD skills VARCHAR(255) NOT NULL AFTER gender"; // ใช้ 255 เเผื่อเก็บหลายอัน
    if (mysqli_query($connect, $sql_skills)) {
        echo "เพิ่มคอลัมน์ skills สำเร็จ<br>";
    } else {
        echo "เพิ่มคอลัมน์ skills ผิดพลาด: " . mysqli_error($connect) . "<br>";
    }
} else {
    echo "มีคอลัมน์ skills อยู่แล้ว<br>";
}

echo '<br><a href="L5insertform.php">กลับไปหน้าแบบฟอร์ม</a>';
?>
