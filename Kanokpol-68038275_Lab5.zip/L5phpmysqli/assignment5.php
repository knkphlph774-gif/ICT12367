<?php
// เชื่อมต่อฐานข้อมูล world
$connect = mysqli_connect("127.0.0.1", "root", "", "world");
if(!$connect){
    die("Connection failed: " . mysqli_connect_error());
}
mysqli_set_charset($connect, "utf8");

$questions = [
    1 => "จงเขียนคำสั่งเพื่อดึงข้อมูลทุกคอลัมน์จากตาราง city",
    2 => "จงแสดงรายชื่อเมือง (Name) และเขตการปกครอง (District) ของทุกเมือง",
    3 => "จงหาชื่อเมืองที่อยู่ในรหัสประเทศ (CountryCode) เป็น 'THA'",
    4 => "จงหาเมืองที่มีจำนวนประชากร (Population) มากกว่า 1,000,000 คน",
    5 => "จงหาเมืองในรหัสประเทศ (CountryCode) เป็น 'BEL' และที่มีจำนวนประชากร (Population) มากกว่า 2,000,000 คน",
    6 => "จงแสดงชื่อประเทศ (Name) และทวีป (Continent) ของทุกประเทศ",
    7 => "จงหาข้อมูลของประเทศที่ตั้งอยู่ในทวีป 'Asia'",
    8 => "จงหาชื่อประเทศที่อยู่ในภูมิภาค (Region) 'Southeast Asia' และมีประชากรมากกว่า 50 ล้านคน",
    9 => "จงหาชื่อประเทศที่มีอายุขัยเฉลี่ย (LifeExpectancy) สูงกว่า 80 ปี",
    10 => "จงหาชื่อประเทศที่ไม่มีข้อมูลปีที่ได้รับเอกราช (IndepYear เป็น NULL)",
    11 => "จงหาชื่อประเทศที่มีค่า GNP ในปัจจุบัน มากกว่าค่า GNP เก่า (GNPOld)",
    12 => "จงแสดงภาษา (Language) ทั้งหมดที่ใช้ในรหัสประเทศ 'USA'",
    13 => "จงหาภาษาที่เป็นภาษาทางการ (IsOfficial = 'T')",
    14 => "จงหาภาษาที่มีสัดส่วนการใช้ (Percentage) มากกว่า 50% ขึ้นไป",
    15 => "จงหาภาษาที่ไม่ใช่ภาษาทางการ (IsOfficial = 'F') แต่มีสัดส่วนการใช้มากกว่า 30%"
];

$queries = [
    1 => "SELECT * FROM city;",
    2 => "SELECT Name, District FROM city;",
    3 => "SELECT Name FROM city WHERE CountryCode = 'THA';",
    4 => "SELECT * FROM city WHERE Population > 1000000;",
    5 => "SELECT * FROM city WHERE CountryCode = 'BEL' AND Population > 2000000;",
    6 => "SELECT Name, Continent FROM country;",
    7 => "SELECT * FROM country WHERE Continent = 'Asia';",
    8 => "SELECT Name FROM country WHERE Region = 'Southeast Asia' AND Population > 50000000;",
    9 => "SELECT Name FROM country WHERE LifeExpectancy > 80;",
    10 => "SELECT Name FROM country WHERE IndepYear IS NULL;",
    11 => "SELECT Name FROM country WHERE GNP > GNPOld;",
    12 => "SELECT Language FROM countrylanguage WHERE CountryCode = 'USA';",
    13 => "SELECT Language FROM countrylanguage WHERE IsOfficial = 'T';",
    14 => "SELECT Language FROM countrylanguage WHERE Percentage >= 50;",
    15 => "SELECT Language FROM countrylanguage WHERE IsOfficial = 'F' AND Percentage > 30;"
];

$q_id = isset($_GET['q']) ? (int)$_GET['q'] : 1;
if (!array_key_exists($q_id, $queries)) {
    $q_id = 1;
}

$sql = $queries[$q_id];
$question_text = $questions[$q_id];

$result = mysqli_query($connect, $sql);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 5 - World Database</title>
    <style>
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background-color: #f4f6f9; 
            color: #333; 
            padding: 20px; 
            display: flex;
        }
        .sidebar {
            width: 300px;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            margin-right: 20px;
            height: fit-content;
        }
        .sidebar h3 {
            margin-top: 0;
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar li {
            margin-bottom: 8px;
        }
        .sidebar a {
            text-decoration: none;
            color: #34495e;
            display: block;
            padding: 8px 10px;
            border-radius: 5px;
            transition: background 0.2s;
        }
        .sidebar a:hover {
            background: #ecf0f1;
        }
        .sidebar a.active {
            background: #3498db;
            color: #fff;
        }
        .content { 
            flex: 1;
            background: #ffffff; 
            padding: 25px; 
            border-radius: 10px; 
            box-shadow: 0 4px 8px rgba(0,0,0,0.1); 
            min-width: 0; /* Prevents overflow */
        }
        h2 { 
            color: #2c3e50; 
            margin-top: 0;
        }
        .question-box {
            background: #e8f4f8;
            padding: 15px;
            border-left: 5px solid #3498db;
            margin-bottom: 20px;
            font-size: 16px;
            line-height: 1.5;
        }
        .sql-code { 
            background: #2d2d2d; 
            color: #f8f8f2; 
            padding: 15px; 
            border-radius: 5px; 
            font-family: Consolas, monospace; 
            font-size: 16px; 
            overflow-x: auto;
            margin-bottom: 20px;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 10px; 
        }
        th, td { 
            border: 1px solid #e0e0e0; 
            padding: 10px 12px; 
            text-align: left; 
            white-space: nowrap; /* Keep table data from wrapping too much */
        }
        th { 
            background-color: #3498db; 
            color: white; 
            font-weight: 600;
            position: sticky;
            top: 0;
        }
        .table-container {
            max-height: 500px;
            overflow-y: auto;
            overflow-x: auto; /* Allow horizontal scroll for many columns */
            border: 1px solid #e0e0e0;
        }
        tr:nth-child(even) { background-color: #f8f9fa; }
        tr:hover { background-color: #e9ecef; }
        .stats {
            margin-top: 15px;
            font-weight: bold;
            color: #27ae60;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h3>Assignment 5 (World DB)</h3>
    <ul>
        <?php for($i=1; $i<=15; $i++): ?>
            <li>
                <a href="?q=<?php echo $i; ?>" class="<?php echo ($i == $q_id) ? 'active' : ''; ?>">
                    โจทย์ข้อที่ <?php echo $i; ?>
                </a>
            </li>
        <?php endfor; ?>
    </ul>
    <div style="margin-top: 30px; border-top: 1px solid #eee; padding-top: 20px;">
        <a href="L5insertForm.php" style="display: block; text-align: center; background-color: #636e72; color: #fff; padding: 10px; border-radius: 5px; text-decoration: none; font-weight: 500; transition: background 0.2s;" onmouseover="this.style.backgroundColor='#2d3436'" onmouseout="this.style.backgroundColor='#636e72'">
            ⬅️ ย้อนกลับไปหน้าฟอร์ม
        </a>
    </div>
</div>

<div class="content">
    <h2>🎯 ผลลัพธ์ Assignment 5 - ข้อที่ <?php echo $q_id; ?></h2>
    
    <div class="question-box">
        <strong>โจทย์:</strong> <?php echo htmlspecialchars($question_text); ?>
    </div>

    <p><strong>คำสั่ง SQL:</strong></p>
    <div class="sql-code"><?php echo htmlspecialchars($sql); ?></div>

    <p><strong>ผลลัพธ์ที่ได้จากฐานข้อมูล:</strong></p>
    <?php
    if($result) {
        $num_rows = mysqli_num_rows($result);
        if($num_rows > 0) {
            echo "<div class='table-container'>";
            echo "<table>";
            
            // Fetch field names for table headers
            $fields = mysqli_fetch_fields($result);
            echo "<tr>";
            foreach($fields as $field) {
                echo "<th>" . htmlspecialchars($field->name) . "</th>";
            }
            echo "</tr>";
            
            // Fetch and display rows
            while($row = mysqli_fetch_assoc($result)){
                echo "<tr>";
                foreach($row as $val) {
                    echo "<td>" . htmlspecialchars((string)$val) . "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
            echo "</div>";
            
            echo "<div class='stats'>✅ พบข้อมูลทั้งหมด " . $num_rows . " แถว</div>";
        } else {
            echo "<p style='color: #e67e22;'>⚠️ ไม่พบข้อมูลที่ตรงกับเงื่อนไข</p>";
        }
    } else {
        echo "<p style='color: #e74c3c;'>❌ เกิดข้อผิดพลาดในคำสั่ง SQL: " . mysqli_error($connect) . "</p>";
    }

    mysqli_close($connect);
    ?>
</div>

</body>
</html>
