<?php
$connect = mysqli_connect("localhost", "root", "");

if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "CREATE DATABASE IF NOT EXISTS mydatab DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci";
if (mysqli_query($connect, $sql)) {
    echo "สร้างฐานข้อมูล mydatab สำเร็จ<br>";
} else {
    echo "Error creating database: " . mysqli_error($connect) . "<br>";
}

mysqli_select_db($connect, "mydatab");

$sql = "CREATE TABLE IF NOT EXISTS employees (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fname VARCHAR(100) NOT NULL,
    lname VARCHAR(100) NOT NULL
)";

if (mysqli_query($connect, $sql)) {
    echo "สร้างตาราง employees สำเร็จ<br>";
} else {
    echo "Error creating table: " . mysqli_error($connect) . "<br>";
}

mysqli_close($connect);
?>
