<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ข้อมูลพนักงาน</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <?php
        require('dbconnect.php');
        $sql = "SELECT * FROM employees ORDER BY fname ASC";
        $result = mysqli_query($connect, $sql);
        $count = mysqli_num_rows($result);
        $order = 1;
        ?>

        <h1 class="text-center my-3">แสดงข้อมูลพนักงานทั้งหมด</h1>
        <br>
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>ลำดับที่</th>
                    <th>ชื่อ</th>
                    <th>นามสกุล</th>
                    <th>เพศ</th>
                    <th>ทักษะความสามารถ</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php echo $order++; ?></td>
                    <td><?php echo $row["fname"]; ?></td>
                    <td><?php echo $row["lname"]; ?></td>
                    <td><?php echo $row["gender"]; ?></td>
                    <td><?php echo $row["skills"]; ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>

        <a href="L5insertform.php" class="btn btn-success">กลับไปหน้ากรอกข้อมูล</a>
    </div>
</body>
</html>
