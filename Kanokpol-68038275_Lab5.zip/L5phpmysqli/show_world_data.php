<?php
// เชื่อมต่อฐานข้อมูล world
$connect = mysqli_connect("127.0.0.1", "root", "", "world");

// ตรวจสอบการเชื่อมต่อ
if(!$connect){
    die("Connection failed: " . mysqli_connect_error());
}

// กำหนด charset ให้เป็น utf8 (รองรับภาษาไทยถ้ามี)
mysqli_set_charset($connect, "utf8");

// คำสั่ง SQL ที่ต้องการรัน
$sql = "SELECT Language FROM countrylanguage WHERE IsOfficial = 'F' AND Percentage > 30";
$result = mysqli_query($connect, $sql);

?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แสดงข้อมูลผลลัพธ์ SQL (ฐานข้อมูล World)</title>
    <style>
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background-color: #f4f6f9; 
            color: #333; 
            padding: 30px; 
        }
        .container { 
            max-width: 700px; 
            margin: 0 auto; 
            background: #ffffff; 
            padding: 25px; 
            border-radius: 10px; 
            box-shadow: 0 4px 8px rgba(0,0,0,0.1); 
        }
        h2 { 
            color: #2c3e50; 
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            margin-top: 0;
        }
        .sql-code { 
            background: #2d2d2d; 
            color: #f8f8f2; 
            padding: 15px; 
            border-radius: 5px; 
            font-family: Consolas, monospace; 
            font-size: 16px; 
            overflow-x: auto;
            margin-bottom: 20px;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 10px; 
        }
        th, td { 
            border: 1px solid #e0e0e0; 
            padding: 12px 15px; 
            text-align: left; 
        }
        th { 
            background-color: #3498db; 
            color: white; 
            font-weight: 600;
        }
        tr:nth-child(even) { background-color: #f8f9fa; }
        tr:hover { background-color: #e9ecef; }
    </style>
</head>
<body>

<div class="container">
    <h2>🚀 ผลลัพธ์ SQL จากฐานข้อมูล <code>world</code></h2>
    
    <p><strong>คำสั่งที่ประมวลผล:</strong></p>
    <div class="sql-code"><?php echo htmlspecialchars($sql); ?>;</div>

    <p><strong>ผลลัพธ์ที่ได้:</strong></p>
    <?php
    if($result && mysqli_num_rows($result) > 0) {
        echo "<table>";
        echo "<tr><th>Language</th></tr>";
        
        // วนลูปเพื่อดึงข้อมูลแต่ละแถวมาแสดงผล
        while($row = mysqli_fetch_assoc($result)){
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row["Language"]) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        echo "<p style='color: green; margin-top: 15px;'>✅ พบข้อมูลทั้งหมด " . mysqli_num_rows($result) . " แถว</p>";
    } else {
        echo "<p style='color: red;'>❌ ไม่พบข้อมูล หรือมีข้อผิดพลาด: " . mysqli_error($connect) . "</p>";
    }

    // ปิดการเชื่อมต่อ
    mysqli_close($connect);
    ?>
</div>

</body>
</html>
